package com.banking.frauddectectionservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FraudDectectionServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FraudDectectionServiceApplication.class, args);
	}

}
